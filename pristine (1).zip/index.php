<?php
include_once 'ContactFunctions.php';

if (isset($_POST) && isset($_POST["btn_submit"])) {
    if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
        echo '<script>window.location="./"</script>';
        exit;
    }

    $name = $email = $phone = $msge = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $secretKey  = '6LcJ8cQkAAAAACnWXE3H_8QxPgM8liTtxHb1IjZz';
        $token    = $_POST["g-token"];
        $ip     = $_SERVER['REMOTE_ADDR'];

        if (empty($_POST["name"])) {
            echo '<script>window.location="./"</script>';
            exit;
        } else {
            $name = filterName($_POST["name"]);
            if ($name == FALSE) {
                echo '<script>window.location="./"</script>';
                exit;
            }
        }

        if (empty($_POST["email"])) {
            echo '<script>window.location="./"</script>';
            exit;
        } else {
            $email = filterEmail($_POST["email"]);
            if ($email == FALSE) {
                echo '<script>window.location="./"</script>';
                exit;
            }
        }

        $phone = (isset($_POST["phone"]) && !empty($_POST["phone"])) ? $_POST["phone"] : '';
        $form_service = (isset($_POST["service"]) && !empty($_POST["service"])) ? $_POST["service"] : '';

        // Validate user message
        if (empty($_POST["description"])) {
            echo '<script>window.location="./"</script>';
            exit;
        } else {
            $msge = filterString($_POST["description"]);
            if ($msge == FALSE) {
                echo '<script>window.location="./"</script>';
                exit;
            }
        }

        $url = "https://www.google.com/recaptcha/api/siteverify";
        $data = array('secret' => $secretKey, 'response' => $token, 'remoteip' => $ip);

        // use key 'http' even if you send the request to https://...
        $options = array('http' => array(
            'method'  => 'POST',
            'content' => http_build_query($data)
        ));
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);
        if ($response->success) {

            //  $to = 'ravi02.agp@gmail.com';
            $to = 'info@pristinecleaningbusiness.com';

            $fromMail = 'no-reply@pristinecleaningbusiness.com';
            $fromName = "Pristine Cleaning Service";
            $subject = "Pristine Cleaning Service - Get Free Estimate";
            $message = '<html><head><title>Pristine Cleaning Service</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
            <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

            <tr>
            <td height="25"  colspan="2"><center><strong>Pristine Cleaning Service</strong></center></td>
            </tr>
            </table>
            <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
                <tbody>
                    <tr>
                        <td width="100%" valign="top">
                            <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                                <tbody>     
                                    <tr>
                                        <td colspan="2"><center><strong>Get Free Estimate</strong></center></td>
                                    </tr>
                                    <tr>
                                        <td width="30%">Name:</td>
                                        <td width="70%">' . $name . '</td>
                                    </tr>
                                    <tr>
                                        <td>Email:</td>
                                        <td>' . $email . '</td>
                                    </tr>
                                    <tr>
                                        <td>Phone:</td>
                                        <td>' . $phone . '</td>
                                    </tr>
                                    <tr>
                                        <td>Subject:</td>
                                        <td>' . $form_service . '</td>
                                    </tr>
                                    <tr>
                                        <td>Message:</td>
                                        <td>' . $msge . '</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div></body></html>';
            // To send HTML mail, the Content-type header must be set
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
            $headers .= 'Bcc: contact@wxperts.co' . "\r\n";
            $message = str_replace("\'", "'", $message);
            //echo $message;exit;
            $send_mail = mail($to, $subject, $message, $headers);

            if ($send_mail) {
                //  echo '<script>window.location="https://www.isadorejohnsonsmiscellaneousservices.com/get-free-estimate.php?submit=success"</script>';die();
                echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
            } else {
                echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
            }
        } else {
            echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
        }
    }
}

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pristine Cleaning Service – Commercial Cleaning Service in Charlotte, NC</title>
    <meta name="description"
        content="Get the best service of commercial cleaning service in Charlotte, NC with the Pristine Cleaning Service. We also provide Residential Cleaning, Maid Services, Eco/Green Cleaning etc.">
    <meta name="keywords"
        content="Pristine Cleaning Service in Charlotte, NC, Commercial Cleaning Service in Charlotte, NC, Residential Cleaning Service in Charlotte, NC, Maid Services in Charlotte, NC, Child Safe Cleaning in Charlotte, NC, Eco/Green Cleaning in Charlotte, NC">
    <?php include("includes/top-header.php"); ?>
    <meta name="google-site-verification" content="FeNJ1bu6JJqCxcgl4lXzEx1i0lP5H5U__S96qg-8X0I" />
    <script src="https://www.google.com/recaptcha/api.js?render=6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh"></script>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-JZMXL3WMQJ"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'G-JZMXL3WMQJ');
    </script>
</head>

<body class="header-1">
    <?php include("includes/header.php"); ?>
    <!-- /.header-one -->
    <div id="main-slider" class="dl-slider">
        <div class="single-slide">
            <div class="bg-img kenburns-top-right" style="background-image: url(assets/img/slider-1.jpg);"></div>
            <div class="slider-content-wrap d-flex align-items-center text-left">
                <div class="container">
                    <div class="slider-content">
                        <div class="dl-caption big">
                            <div class="inner-layer">
                                <div data-animation="fade-in-left" data-delay="2s">Top of the line cleaning services<br>
                                    for your home & offices.</div>
                            </div>
                        </div>
                        <div class="dl-btn-group">
                            <div class="inner-layer">
                                <a href="<?php echo SITEURL ?>#get-service" class="dl-btn" data-animation="fade-in-left"
                                    data-delay="3.5s">Get Our Services <i class="arrow_right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Slide-1-->
        <div class="single-slide">
            <div class="bg-img kenburns-top-right"
                style="background-image: url(<?php echo SITEURL  ?>assets/img/slider-2.jpg);"></div>
            <div class="slider-content-wrap d-flex align-items-center text-left">
                <div class="container">
                    <div class="slider-content">
                        <div class="dl-caption big">
                            <div class="inner-layer">
                                <div data-animation="fade-in-left" data-delay="2s">Delivering expert<br> disinfection &
                                    sterilization for your property</div>
                            </div>
                        </div>
                        <div class="dl-btn-group">
                            <div class="inner-layer">
                                <a href="<?php echo SITEURL ?>#get-service" class="dl-btn" data-animation="fade-in-left"
                                    data-delay="3.5s">Get Our Services <i class="arrow_right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Slide-2-->
        <div class="single-slide">
            <div class="bg-img kenburns-top-right"
                style="background-image: url(<?php echo SITEURL ?>assets/img/slider-3.jpg);"></div>
            <div class="slider-content-wrap d-flex align-items-center text-left">
                <div class="container">
                    <div class="slider-content">
                        <div class="dl-caption big">
                            <div class="inner-layer">
                                <div data-animation="fade-in-left" data-delay="2s">Looking after your health &amp;
                                    Wellness</div>
                            </div>
                        </div>
                        <div class="dl-btn-group">
                            <div class="inner-layer">
                                <a href="<?php echo SITEURL ?>#get-service" class="dl-btn" data-animation="fade-in-left"
                                    data-delay="3.5s">Get Our Services <i class="arrow_right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Slide-3-->
    </div><!-- slider-section -->
    <?php $welcome_data = $mv_welcome->index(); ?>
    <section class="about-section padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 sm-padding">
                    <div class="about-content welcome">
                        <div class="section-heading wow fadeInLeft" data-wow-delay="0">
                            <h1>Pristine Cleaning Service</h1>
                            <h2 class="dis-none">Residential and Commercial Cleaning Services in Charlotte, NC</h2>
                            <p><?php echo isset($welcome_data['description'])? $welcome_data['description']: '' ?></p>
                        </div>
                        <ul class="about-list">
                            <li class="wow fadeInLeft" data-wow-delay="200ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Trustworthy</h3>
                                </div>
                            </li>
                            <li class="wow fadeInLeft" data-wow-delay="400ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Respect</h3>
                                </div>
                            </li>
                            <li class="wow fadeInLeft" data-wow-delay="400ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Integrity</h3>
                                </div>
                            </li>
                            <li class="wow fadeInLeft" data-wow-delay="400ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Accountability</h3>
                                </div>
                            </li>
                            <li class="wow fadeInLeft" data-wow-delay="400ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Sustainability</h3>
                                </div>
                            </li>
                            <li class="wow fadeInLeft" data-wow-delay="400ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3>Innovation</h3>
                                </div>
                            </li>
                        </ul>
                        <ul class="about-btn wow fadeInLeft" data-wow-delay="600ms">
                            <li>
                                <a href="<?php echo SITEURL ?>about-us.php" class="default-btn">Read
                                    More<span></span></a>
                                <a class="whatsapp"
                                    href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><i
                                        class="fab fa-whatsapp"></i>
                                    <?php echo isset($contact['phone'])? $contact['phone']: '' ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 sm-padding" id="get">
                    <div class="booking-form" id="get-service">
                        <div class="form-heading">
                            <h3 class="chng-clr">Get Free Estimate</h3>
                        </div>
                        <form action="#" method="post" id="ajax_appointment" class="form-horizontal">
                            <div class="form-group colum-row row">
                                <input type="hidden" id="g-token" name="g-token" />
                                <div class="col-sm-6">
                                    <input type="text" id="name" name="name" class="form-control" placeholder="Name"
                                        required>
                                </div>
                                <div class="col-sm-6">
                                    <input type="email" id="email" name="email" class="form-control" placeholder="Email"
                                        required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6">
                                    <input type="text" id="phone" name="phone" class="form-control" placeholder="Phone"
                                        required>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" id="service" name="service" class="form-control"
                                        placeholder="Service" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <textarea id="message" name="description" maxlength="100" cols="30" rows="5"
                                        class="form-control address" placeholder="Message" required></textarea>
                                </div>
                            </div>
                            <button id="submit" class="default-btn" name="btn_submit" type="submit">Submit</button>
                            <div id="form-messages" class="alert" role="alert"></div>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </section><!-- /.about-section -->
    <?php $service_data = $service->index(2); ?>
    <section class="features-section padding bg-grey">
        <div class="features-bg"></div>
        <div class="container">
            <div class="row">
                <?php foreach($service_data as $stm) ?>
                <div class="col-lg-6 wow fadeInLeft" data-wow-delay="200ms">
                    <div class="section-heading mb-20">
                        <h3 class="text-white">Residential Cleaning</h3>
                        <p class="text-white">
                            <?php echo isset($welcome_data['description_1'])? $welcome_data['description_1']: '' ?></p>
                    </div>
                    <a href="<?php echo SITEURL . 'residential/' . $stm['alias']; ?>" class="default-btn mb-20">Read
                        More<span></span></a>

                    <div class="section-heading mb-20">
                        <h3 class="text-white">Commercial Cleaning</h3>
                        <p class="text-white">
                            <?php echo isset($welcome_data['description_2'])? $welcome_data['description_2']: '' ?></p>
                    </div>
                    <a href="<?php echo SITEURL . 'residential/' . $stm['alias']; ?>" class="default-btn mb-20">Read
                        More<span></span></a>
                </div>
            </div>
        </div>
    </section>
    <?php $service_data = $service->index(2); ?>
    <?php $service_home_data = $service_home->index($honepage = 1); ?>
    <section class="service-section padding">
        <div class="container">
            <div class="section-heading text-center mb-40 wow fadeInUp" data-wow-delay="200ms">
                <img src="<?php echo SITEURL ?>assets/img/clean.png" alt="Pristine Cleaning Service in Charlotte, NC">
                <h3 class="chng-clr">Our Services</h3>
            </div>
            <div class="row">
                <?php foreach($service_data as $stm) ?>
                <?php foreach ($service_home_data as $home_service) {  ?>
                <div class="col-lg-4 col-md-6 sm-padding wow fadeInUp" data-wow-delay="300ms">
                    <div class="service-card">
                        <div class="service-thumb">
                            <img src="<?php echo isset($home_service['photourl']) ? $home_service['photourl'] : ' ' ?>"
                                alt="<?php echo isset($home_service['alt_name']) ? $home_service['alt_name'] : ' ' ?>">
                        </div>
                        <div class="service-content">
                            <h3><a
                                    href="<?php echo SITEURL . 'residential/' . $stm['alias']; ?>"><?php echo isset($home_service['name']) ? $home_service['name'] : '' ?></a>
                            </h3>
                            <a href="<?php echo SITEURL . 'residential/' . $stm['alias']; ?>" class="read-more"><i
                                    class="fas fa-share"></i></a>
                        </div>
                    </div>
                </div>
                <?php }  ?>
            </div>
        </div>
    </section><!-- /.service-section -->

    <section class="work-process-section padding">
        <div class="container">
            <div class="section-heading text-center mb-40 wow fadeInUp" data-wow-delay="200ms">
                <img src="<?php echo SITEURL ?>assets/img/clean.png" alt="Commercial Cleaning Service in Charlotte">
                <h3 class="chng-clr">4 Steps Following We Complete Work</h3>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6 sm-padding wow fadeInUp" data-wow-delay="200ms">
                    <div class="work-pro-item">
                        <i class="far fa-calendar-check"></i>
                        <h3>Get Estimate</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding wow fadeInUp" data-wow-delay="300ms">
                    <div class="work-pro-item">
                        <i class="far fa-hand-pointer"></i>
                        <h3>Confirm Your Service</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding wow fadeInUp" data-wow-delay="400ms">
                    <div class="work-pro-item">
                        <i class="fas fa-broom"></i>
                        <h3>Cleaning With Care</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 sm-padding wow fadeInUp" data-wow-delay="500ms">
                    <div class="work-pro-item">
                        <i class="far fa-thumbs-up"></i>
                        <h3>Get Your Result</h3>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /.work-process-section -->
    <?php $gallery_data = $gallery->index($homepage = 1); ?>
    <!-- /.features-section -->
    <section class="project-section bg-grey padding">
        <div class="container-fluid">
            <div class="section-heading text-center mb-40 wow fadeInUp" data-wow-delay="200ms">
                <img src="<?php echo SITEURL ?>assets/img/clean.png" alt="Residential Cleaning Service in Charlotte">
                <h3 class="text-white">Our Work</h3>
            </div>

            <div class="slider project-carousel nav-style carousel-dots">
                <?php foreach ($gallery_data as $Home_img) { ?>
                <div class="project-item">
                    <div class="project-inner">
                        <img src="<?php echo SITEURL ?><?php echo isset($Home_img['photourl']) ? $Home_img['photourl'] : '' ?>"
                            alt="<?php echo isset($Home_img['alt_name_home']) ? $Home_img['alt_name_home'] : '' ?>">
                    </div>
                </div>
                <?php } ?>

            </div>
        </div>
    </section><!-- /.project-section -->
    <?php $testimonials = $pr_testimonials->index(); ?>
    <section class="testimonials-section padding">
        <div class="container">
            <div class="section-heading text-center mb-40 wow fadeInUp" data-wow-delay="200ms">
                <img src="<?php echo SITEURL ?>assets/img/clean.png"
                    alt="Best Disinfection Cleaning Company in North Carolina">
                <h3 class="chng-clr">Our Happy Clients</h3>
            </div>
            <div class="slider testimonials-carousel nav-style carousel-dots">
                <?php foreach ($testimonials as $testimonial) { ?>
                <div class="testi-item">
                    <div class="testi-inner">
                        <img src="<?php echo SITEURL ?><?php echo isset($testimonial['photourl']) ? $testimonial['photourl'] : '' ?>"
                            alt="<?php echo isset($testimonial['alt_name']) ? $testimonial['alt_name'] : '' ?>">
                        <h3><?php echo isset($testimonial['name']) ? $testimonial['name'] : '' ?></h3>
                    </div>
                    <p><?php echo isset($testimonial['description']) ? html_entity_decode($testimonial['description']) : '' ?></p>
                </div>
                <?php } ?>
            </div>
        </div>
    </section><!-- /.testimonial-section -->
    <?php include("includes/footer.php"); ?>

    <script>
    grecaptcha.ready(function() {
        grecaptcha.execute('6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh', {
            action: 'homepage'
        }).then(function(token) {
            //console.log(token);
            document.getElementById("g-token").value = token;
        });
    });
    </script>

</body>

</html>