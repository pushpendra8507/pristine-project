<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blogs -House & Office Cleaning Charlotte, NC -Pristine Cleaning Service</title>
    <meta name="description" content="Discover the ultimate solution for Home & Office Cleaning in Charlotte, NC at Pristine Cleaning Service. Explore our insightful blogs for expert tips.">
    <meta name="keywords" content="Home & Office Cleaning, Residential and Commercial Cleaning in Charlotte, NC, Residential Cleaning Service, Child Safe Cleaning, Eco/Green Cleaning, Janitorial Cleaning in Charlotte, NC">
    <?php include("includes/top-header.php"); ?>
</head>

<body class="header-1">
    <?php include("includes/header.php"); ?>
    <section class="page-header-2 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none">Blogs - Home & Office Cleaning in Charlotte</h1>
                <h2 class="dis-none">Professional Office Cleaning near me Charlotte, NC</h2>
                <h3 class="chng-clr">Blogs</h3>
            </div>
        </div>
    </section>
    <?php $all_projects = $mv_blog->index_limit(); ?>
    <section class="blog-section padding">
        <div class="container">
            <div class="blog-wrap row">
                <div class="col-lg-8 sm-padding">
                    <div class="row">
                        <?php foreach($all_projects as $blog_details){ ?>
                        <div class="col-lg-12 padding-15">
                            <div class="blog-item">
                                    <div class="blog-thumb">
                                        <img src="<?php echo SITEURL ?><?php echo isset($blog_details['photourl']) ? $blog_details['photourl'] : '' ?>" alt="<?php echo isset($blog_details['alt_name']) ? $blog_details['alt_name'] : '' ?>">
                                        <span class="category"> <i class="fa fa-calendar" aria-hidden="true"></i> <?php echo isset($blog_details['date']) ? $blog_details['date'] : '' ?> <i class="fa fa-comment"></i> 0 Comments</span>
                                    </div>
                                    <div class="blog-content">
                                        <h3><a href="<?php echo SITEURL . 'blogs/' . $blog_details['alias']; ?>"><?php echo isset($blog_details['title']) ? $blog_details['title'] : '' ?></a></h3>
                                        <p><?php echo isset($blog_details['description']) ? substr(strip_tags($blog_details['description']),0, 180) : ''; ?></p>
                                        <a href="<?php echo SITEURL . 'blogs/' . $blog_details['alias']; ?>" class="read-more">Read More</a>
                                    </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>

               <?php include('includes/sidebar.php'); ?>
            </div>
            </div>
    </section>

    <?php include("includes/footer.php"); ?>
</body>

</html>