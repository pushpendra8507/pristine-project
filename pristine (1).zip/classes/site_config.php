<?php
ob_start();
/*database credentials*/

// define('DB_HOST','localhost');
// define('DB_USER','root');
// define('DB_PASSWORD','');
// define('DB_NAME','db_pristine');
// define('SITEURL', 'http://localhost/pristine/');
// define('SITELOGO', 'http://localhost/pristine/assets/img/logo.webp');

define('DB_HOST','localhost');
define('DB_USER','pristine_db');
define('DB_PASSWORD','^?i$Ob$8R7V3');
define('DB_NAME',  'pristine_db');
define('SITEURL',  'https://pristinecleaningclt.com/');
define('SITELOGO', 'https://pristinecleaningclt.com/assets/img/logo.webp');





/*Manage Site Currency */
define('SITE_CURRENCY','$');
/*site title for admin pages*/
define('ADMIN_TITLE','Pristine Cleaning Service');

/** email setting */
define('MAIL_TITLE',"Pristine Cleaning Service");

define('ADMIN_EMAIL','info@pristinecleaningbusiness.com');

define('FROM_EMAIL','no-reply@pristinecleaningclt.com');
define('FROM_NAME','Pristine Cleaning Service');
define('BCC_EMAIL','');



/** security settings */
define('SECURITY_KEY','i~am~iron~man');
define('ADMIN_SESSION','mv_admin');
define('ADMIN_SESSION_EMAIL','mv_admin_email');



?>