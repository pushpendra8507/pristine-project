<?php
class MV_AboutUs extends Database{
	public function __construct()
	{
		parent::__construct();
	}

    public function index(){
        $stmt =  $this->connection->prepare("SELECT * FROM `tbl_aboutus` where `id`=1");
        $stmt ->execute();

        return  $stmt->fetch(PDO::FETCH_ASSOC);
    }
   
    public function update($data){
        $description = isset($data['description'])?$data['description']:'';
        $title = isset($data['title'])?$data['title']:'';
       
        
        
        $stmt = $this->connection->prepare("UPDATE `tbl_aboutus` SET `description`=?,`title`=?  WHERE `id`=1");
        $stmt->bindParam(1,$description);
        $stmt->bindParam(2,$title);
       
        return ($stmt->execute())?1:0;
    }
}
?>