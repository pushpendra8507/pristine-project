<?php
class MV_Welcome extends Database{
	public function __construct()
	{
		parent::__construct();
	}

    public function index(){
        $stmt =  $this->connection->prepare("SELECT * FROM `tbl_welcome` where `id`=1");
        $stmt ->execute();

        return  $stmt->fetch(PDO::FETCH_ASSOC);
    }
   
    public function update($data){
        $title = isset($data['title'])?$data['title']:'';
        $description = isset($data['description'])?$data['description']:'';        
        $description_1 = isset($data['description_1'])?$data['description_1']:'';
        $description_2 = isset($data['description_2'])?$data['description_2']:'';
        
        
        $stmt = $this->connection->prepare("UPDATE `tbl_welcome` SET `title`=?,`description`=?,`description_1`=?, `description_2`=? WHERE `id`=1");
        $stmt->bindParam(1,$title);
        $stmt->bindParam(2,$description);
        $stmt->bindParam(3,$description_1);
        $stmt->bindParam(4,$description_2);
        return ($stmt->execute())?1:0;
    }
}
?>