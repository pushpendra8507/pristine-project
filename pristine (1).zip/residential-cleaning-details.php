<?php
include('classes/startup.php');
$core    = new Core;
$service = new MV_Service;

if (!isset($_REQUEST['alias']) || empty($_REQUEST['alias'])) {
    header('location:index.php');
    exit;
}
?>
<!doctype html>
<html class="no-js" lang="en">
<?php $service_seo = $service->get_details_by_alias($_REQUEST['alias']); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo isset($service_seo['seo_title']) ? $service_seo['seo_title'] : '' ?></title>
    <meta name="description" content="<?php echo isset($service_seo['seo_description']) ? $service_seo['seo_description'] : '' ?>">
    <meta name="keywords" content="<?php echo isset($service_seo['seo_keyword']) ? $service_seo['seo_keyword'] : '' ?>">
    <?php include("includes/top-header.php"); ?>
</head>

<body class="header-1">
    <?php include("includes/header.php"); ?>
    <section class="page-header-2 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none"><?php echo isset($service_seo['seo_h1']) ? $service_seo['seo_h1'] : '' ?></h1>
                <h2 class="dis-none"><?php echo isset($service_seo['seo_h2']) ? $service_seo['seo_h2'] : '' ?></h2>
                <h3 class="chng-clr"><?php echo isset($service_seo['name']) ? $service_seo['name'] : '' ?></h3>
            </div>
        </div>
    </section>
    <?php $residential  = $service->get_details_by_alias($_REQUEST['alias']); ?>
    <?php $service_provider = isset($residential['service_provider']) ? json_decode($residential['service_provider'], true) : ""; ?>
    <section class=" padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 sm-padding">
                    <div class="about-content">
                        <div class="section-heading wow fadeInLeft" data-wow-delay="0">
                            <!-- <h3 class="chng-clr">Residential</h3> -->
                            <p><?php echo isset($residential['description']) ? $residential['description'] : '' ?></p>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class=" col-lg-12 col-md-12">
                    <div class="about-bg-holder about-img">
                        <img src="<?php echo SITEURL ?><?php echo isset($residential['photourl']) ? $residential['photourl'] : '' ?>" alt="<?php echo isset($residential['alt_name']) ? $residential['alt_name'] : '' ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 mt-5">
                    <ul class="about-list">
                        <?php
                        foreach ($service_provider as $value) {   ?>
                            <li class="wow fadeInLeft" data-wow-delay="200ms">
                                <i class="fas fa-check"></i>
                                <div class="about-list-content">
                                    <h3><?php echo  $value['title']; ?></h3>
                                </div>
                            </li>
                        <?php  } ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <?php include("includes/footer.php"); ?>
</body>

</html>