<?php
include('classes/startup.php');
$core    = new Core;
$others = new MV_Others;

if (!isset($_REQUEST['alias']) || empty($_REQUEST['alias'])) {
    header('location:index.php');
    exit;
}
?>
<?php $other_seo = $others->get_details_by_alias($_REQUEST['alias']); ?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo isset($other_seo['seo_title']) ? $other_seo['seo_title'] : '' ?></title>
    <meta name="description"
        content="<?php echo isset($other_seo['seo_description']) ? $other_seo['seo_description'] : '' ?>">
    <meta name="keywords" content="<?php echo isset($other_seo['seo_keyword']) ? $other_seo['seo_keyword'] : '' ?>">
    <?php include("includes/top-header.php"); ?>
</head>

<body class="header-1">
    <?php include("includes/header.php"); ?>
    <section class="page-header-2 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none"><?php echo isset($other_seo['seo_h1']) ? $other_seo['seo_h1'] : '' ?></h1>
                <h2 class="dis-none"><?php echo isset($other_seo['seo_h2']) ? $other_seo['seo_h2'] : '' ?></h2>
                <h2 class="chng-clr"><?php echo isset($other_seo['title']) ? $other_seo['title'] : '' ?></h2>
            </div>
        </div>
    </section>
    <?php $other = $others->get_details_by_alias($_REQUEST['alias']); ?>
    <?php $service_provider = isset($other['service_provider']) ? json_decode($other['service_provider'], true) : ""; ?>
    <section class="padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 sm-padding">
                    <div class="about-content">
                        <div class="section-heading wow fadeInLeft" data-wow-delay="0">

                            <p><?php echo isset($other['description']) ? $other['description'] : '' ?></p>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class=" col-lg-12 col-md-12">
                    <div class="about-bg-holder about-img">
                        <img src="<?php echo SITEURL ?><?php echo isset($other['photourl']) ? $other['photourl'] : '' ?>"
                            alt="<?php echo isset($other['alt_name']) ? $other['alt_name'] : '' ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 mt-5">
                    <!-- <p><strong>We target critical areas, such as:</strong></p>/ -->
                    <ul class="about-list">
                        <?php
                        foreach ($service_provider as $value) {   ?>
                        <li class="wow fadeInLeft" data-wow-delay="200ms">
                            <i class="fas fa-check"></i>
                            <div class="about-list-content">
                                <h3><?php echo  $value['title']; ?></h3>
                            </div>
                        </li>
                        <?php  } ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <?php include("includes/footer.php"); ?>
</body>

</html>