<?php
include'classes/startup.php';
include_once 'ContactFunctions.php';
$appointments = new Appointments;

if(isset($_POST) && isset($_POST["btn_submit"]))
{
    if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
        echo '<script>window.location="./"</script>'; exit;
    }

    $name = $email = $phone  = $address = $residential = $commercial = $date_time=  $time  = $msge = "";
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {

        $secretKey  = '6LcJ8cQkAAAAACnWXE3H_8QxPgM8liTtxHb1IjZz';
        $token    = $_POST["g-token"];
        $ip     = $_SERVER['REMOTE_ADDR'];
      
        if(empty($_POST["name"]))
        {
            echo '<script>window.location="./"</script>'; exit;
        } 
        else
        {
            $name = filterName($_POST["name"]);
            if($name == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
    
        if(empty($_POST["email"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $email = filterEmail($_POST["email"]);
            if($email == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }

        
         $phone = (isset($_POST["phone"]) && !empty($_POST["phone"]))? $_POST["phone"]: '';
         $address = (isset($_POST["address"]) && !empty($_POST["address"]))? $_POST["address"]: '';
         $residential = (isset($_POST["residential"]) && !empty($_POST["residential"]))? $_POST["residential"]: '';
         $commercial = (isset($_POST["commercial"]) && !empty($_POST["commercial"]))? $_POST["commercial"]: '';
         $date = (isset($_POST["date"]) && !empty($_POST["date"]))?date("Y-m-d", strtotime($_POST["date"])):'';
         $time = (isset($_POST["date"]) && !empty($_POST["time"]))?date("H:i", strtotime($_POST["time"])):'';
         $date_time = date('Y-m-d H:i:s', strtotime($date."  ".$time));
        
        
         

        // Validate user message
        if(empty($_POST["description"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $msge = filterString($_POST["description"]);
            if($msge == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
 
        $url = "https://www.google.com/recaptcha/api/siteverify";
        $data = array('secret' => $secretKey, 'response' => $token, 'remoteip'=> $ip);

          // use key 'http' even if you send the request to https://...
        $options = array('http' => array(
            'method'  => 'POST',
            'content' => http_build_query($data)
        ));
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);
        //echo '<pre>';print_r($response);die();
        if($response->success)
        {
            
            $payload = [];
            $payload['name'] = isset($_POST['name'])?$_POST['name']:'';
            $payload['email'] = isset($_POST['email'])?$_POST['email']:'';
            $payload['phone'] = isset($_POST['phone'])?$_POST['phone']:'';
            $payload['address'] = isset($_POST['address'])?$_POST['address']:'';
            $payload['residential'] = isset($_POST['residential'])?$_POST['residential']:'';
            $payload['commercial'] = isset($_POST['commercial'])?$_POST['commercial']:'';
            $payload['date'] = isset($_POST['date'])?$_POST['date']:'';
            $payload['time'] = isset($_POST['time'])?$_POST['time']:'';
            $payload['description'] = isset($_POST['description'])?$_POST['description']:'';
            
            
            if(!empty($payload['name']) && !empty($payload['email']) && !empty($payload['phone']) && !empty($payload['address']) && !empty($payload['residential']) &&   !empty($payload['commercial']) &&   !empty($payload['date']) && !empty($payload['time']) &&   !empty($payload['date']) && !empty($payload['description']))
            {
                $appointments->create_appointment($payload);
            }
        
            
            define('BUSINESS_NAME','Pristine Cleaning Service');
            define('FORM_TYPE','Book Now');
             $to = 'info@pristinecleaningbusiness.com';
            //   $to = 'ghansraj82@gmail.com';
           
            $fromMail = 'no-reply@pristinecleaningclt.com';
            $fromName = BUSINESS_NAME;
            $subject = BUSINESS_NAME.' - '.FORM_TYPE;
            $message = '<html><head><title>'.BUSINESS_NAME.'</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
                <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

                <tr>
                <td height="25"  colspan="2"><center><strong>'.BUSINESS_NAME.'</strong></center></td>
                </tr>
                </table>
                <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
                    <tbody>
                        <tr>
                            <td width="100%" valign="top">
                                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                                    <tbody>     
                                        <tr>
                                            <td colspan="2"><center><strong>'.FORM_TYPE.'</strong></center></td>
                                        </tr>
                                        <tr>
                                            <td width="30%">Name:</td>
                                            <td width="70%">' . $name . '</td>
                                        </tr>
                                        <tr>
                                            <td>Email:</td>
                                            <td>' . $email . '</td>
                                        </tr>
                                        <tr>
                                            <td>Phone:</td>
                                            <td>' . $phone . '</td>
                                        </tr>
                                        
                                        <tr>
                                       <td>Date:</td>
                                            <td>' . $date . '</td>
                                        </tr>
                                        
                                         <tr>
                                            <td>Time:</td>
                                            <td>' . $time . '</td>
                                        </tr>
                                        
                                        
                                        
                                          <tr>
                                            <td>Address:</td>
                                            <td>' . $address . '</td>
                                        </tr>
                                         <tr>
                                            <td>Residential Cleaning Service:</td>
                                            <td>' . $residential . '</td>
                                        </tr>
                                         <tr>
                                            <td>Commercial Cleaning Service:</td>
                                            <td>' . $commercial . '</td>
                                        </tr>
                                        <tr>
                                            <td>Message:</td>
                                            <td>' . $msge . '</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div></body></html>';
                // To send HTML mail, the Content-type header must be set
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
                $headers .= 'From:'.$fromName." ".'<'.$fromMail.'>'."\r\n";
                 $headers .= 'Bcc: wxperts.co@gmail.com,contact@wxperts.co' . "\r\n";
                  $headers .= 'cc: info@pristinecleaningbusiness.com' . "\r\n";
                $message = str_replace("\'", "'", $message);
                //echo $message;exit;
                $send_mail = mail($to, $subject, $message, $headers);

                if($send_mail)
                {
                   echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
               }
               else 
               {
                   echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
               }
           }
           else
           {
            echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
           }
        }
}

?>


<!doctype html>
   <html class="no-js" lang="en">
   <head>
      <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Residential Cleaning Service in Charlotte, NC - Pristine Cleaning Service</title>
        <meta name="description" content="Embrace a refreshing approach to residential cleaning service in Charlotte, NC with Pristine Cleaning. We transform your home into a haven of immaculate beauty. Visit Us now!">
        <meta name="keywords" content="Professional Office Cleaning, Commercial Cleaning Service, Best Disinfection Cleaning Company in North Carolina, Best Regular Cleaning, Janitorial Cleaning Service, Residential Cleaning Service in Charlotte, NC">
       <?php include ("includes/top-header.php");?>
       
       <script src="https://www.google.com/recaptcha/api.js?render=6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh"></script>
</head>
<body class="header-1">
    <?php include ("includes/header.php");?>
    <section class="page-header-1 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none"></h1>
                <h2 class="dis-none"></h2>
                <h3 class="chng-clr">Book Now</h3>
            </div>
        </div>
    </section>
    <section class="padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 sm-padding" id="get" >
                        <div class="booking-form" id="get-service">
                            <div class="form-heading">
                                <h3 class="chng-clr">Fill The Form</h3>
                            </div>
                            <form action="#" method="post" id="ajax_appointment" class="form-horizontal">
                                        <input type="hidden" id="g-token" name="g-token"/>
                                <div class="form-group colum-row row">
                                    
                                    <div class="col-sm-6">
                                        <span>Name</span>
                                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Email</span>
                                        <input type="email" name="email" class="form-control" placeholder="Email" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <span>Phone</span>
                                        <input type="text" name="phone" class="form-control" placeholder="Phone" required>
                                    </div>
                                    <div class="col-sm-12">
                                        <span>Date</span>
                                        <input type="date" name="date" class="form-control" required>
                                    </div>
                                    
                                      <div class="col-sm-12">
                                        <span>Time</span>
                                        <input type="time" name="time" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <span>Address</span>
                                        <input type="text" name="address" class="form-control" placeholder="Address" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <span>Residential Cleaning Service</span>
                                        <select name="residential">
                                            <option>SELECT----Residential Cleaning Services</option>
                                            <option>Regular Cleaning</option>
                                            <option>Green Cleaning</option>
                                            <option>Sanitization & Deep Cleaning</option>
                                            <option>Move-In/Move-Out Cleaning</option>
                                            <option>Disinfection Cleaning</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <span>Commercial Cleaning Service</span>
                                        <select name="commercial">
                                            <option>SELECT----Commercial Cleaning Services</option>
                                            <option>Office Cleaning</option>
                                            <option>Janitorial Cleaning</option>
                                            <option>Airbnb Cleaning</option>
                                            <option>Post-Construction Cleaning</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <span>Message</span>
                                        <textarea name="description" maxlength="100" cols="30" rows="5" class="form-control address" placeholder="Message" required></textarea>
                                    </div>
                                </div>
                                <button id="submit" class="default-btn" name="btn_submit" type="submit">Submit</button>
                                <div id="form-messages" class="alert" role="alert"></div>
                            </form>

                        </div>
                        
                    </div>
             <div class="col-md-6 sm-padding">
                <div class="about-bg-holder about-img">
                    <img src="assets/img/book-now.jpg" alt="Home & Office Cleaning in Charlotte, NC">
                </div>
            </div>
            
            
        </div>
    </div>
</section>
<script>
        grecaptcha.ready(function() {
        grecaptcha.execute('6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh', {action: 'homepage'}).then(function(token) {
            //console.log(token);
            document.getElementById("g-token").value = token;
        });
        });
</script>
<?php include ("includes/footer.php");?>
</body>
</html>
