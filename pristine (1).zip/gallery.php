<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gallery - Best Regular Cleaning in Charlotte, NC - Pristine Cleaning Service</title>
    <meta name="description"
        content="Explore a gallery of perfection with the best regular cleaning in Charlotte, NC at the Pristine Cleaning Service. Visit now to Witness the art of cleanliness.">
    <meta name="keywords"
        content="Best Regular Cleaning in Charlotte, NC, Glass Door Cleaning, Professional Office Cleaning, Janitorial Cleaning Service, Best Green Cleaning Service, Sanitization & Deep Cleaning Service in North & South Carolina">
    <?php include ("includes/top-header.php");?>
</head>
<body class="header-1">
    <?php include ("includes/header.php");?>
    <section class="page-header-3 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none">Gallery - Best Regular Cleaning in Charlotte, NC</h1>
                <h2 class="dis-none">Best Airbnb Cleaning Service in North Carolina</h2>
                <h3 class="chng-clr">Gallery</h3>
            </div>
        </div>
    </section>
    <?php  $gallery_data = $gallery->index(2); ?>
    <section class="project-section padding">
        <div class="container">
            <div class="row">
                <?php foreach($gallery_data as $data){ ?>
                <div class="col-lg-4 col-sm-6 padding-15 project-item">
                    <div class="project-inner">
                        <img src="<?php echo SITEURL ?><?php echo isset($data['photourl'])? $data['photourl']: '' ?>"alt="<?php echo isset($data['alt_name_gallery'])? $data['alt_name_gallery']: '' ?>">
                    </div>
                </div>
                <?php } ?>  
            </div>
        </div>
    </section>
    <?php include ("includes/footer.php");?>
</body>
</html>