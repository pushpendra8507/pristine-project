<?php
include("classes/startup.php");
$core  = new Core;
$business_hours = isset($contact['business_hours']) ? json_decode($contact['business_hours'], true) : "";

?>

<footer class="footer-section bg-grey">
            <div class="container">
                <div class="row padding">
                    <div class="col-lg-4 col-md-6 sm-padding">
                        <div class="footer-item footer-heading">
                            <h3>Quick Links</h3>
                            <ul>
                                <li><a href="<?php echo SITEURL?>">Home</a></li>
                                <li><a href="<?php echo SITEURL?>about-us.php">About Us</a></li>
                                <li><a href="#">Services</a></li>
                                <li><a href="<?php echo SITEURL?>gallery.php">Gallery</a></li>
                                <li><a href="<?php echo SITEURL?>contact-us.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 sm-padding">
                        <div class="footer-item footer-heading">
                            <h3>Contact Information</h3>
                            <p><a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><i class="fa fa-phone-volume"></i> <?php echo isset($contact['phone'])? $contact['phone']: '' ?></a></p>
                            <p><a href="https://maps.app.goo.gl/i1Lsm12HU5n7RBii9" target="_blank"> <i class="fa fa-map-marker-alt"></i> <?php echo isset($contact['address'])? $contact['address']: '' ?></a></p>
                            <p><a href="mailto:<?php echo isset($contact['email'])? $contact['email']: '' ?>"><i class="fa fa-envelope"></i> <?php echo isset($contact['email'])? $contact['email']: '' ?></a></p>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6 sm-padding">
                        <div class="footer-item footer-heading">
                            <h3>Business Hours</h3>
                            <p><?php
                foreach ($business_hours as $value) {
                  echo '<strong>' . $value['title'] . ': </strong>' . $value['value_1'] . ' ' . $value['value_2'] . ' ' . $value['value_3'] . ' ' . $value['value_4'] . '<br><br>';
                }
                ?></p>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <p class="copyright">&copy; 2023 Pristine Cleaning Service. All Rights Reserved<br>
                        <!--<a href="https://www.wxperts.co/website-development.php" target="_blank">Website Development</a> | <a href="https://www.wxperts.co/" target="_blank">Hosting</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Digital Marketing</a><br>-->
                        <!--<a href="https://www.wxperts.co/" target="_blank"><img src="<?php echo SITEURL?>assets/img/wxperts_powerdby.jpg" alt="webxperts"></a></a></p>-->
                    </div>
                </div>
            </div>
        </footer><!-- /.footer-section -->

		<div id="scrollup">
            <button id="scroll-top" class="scroll-to-top"><i class="ti-angle-up"></i></button>
        </div>

		<!-- jQuery Lib -->
		<script src="<?php echo SITEURL?>assets/js/vendor/jquery-1.12.4.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/vendor/bootstrap.min.js"></script>
        <script src="<?php echo SITEURL?>assets/js/vendor/waypoints.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/vendor/slick.min.js"></script>
        <script src="<?php echo SITEURL?>assets/js/vendor/jquery.smoothscroll.min.js"></script>
        <script src="<?php echo SITEURL?>assets/js/vendor/jquery.magnific-popup.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/vendor/jquery.mb.YTPlayer.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/vendor/jquery.nice-select.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/vendor/wow.min.js"></script>
		<script src="<?php echo SITEURL?>assets/js/main.js"></script>