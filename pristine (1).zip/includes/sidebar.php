<?php
include("classes/startup.php");
$core  = new Core;
?>
                <?php  $all_projects = $mv_blog->index_limit(); ?>
                  <div class="col-lg-4 padding-15">
                    <div class="sidebar-wrap">
                        <div class="widget-content">
                            <div class="widget-content">
                                <h4>Recent Posts</h4>
                                <ul class="thumb-post">
                                    <?php foreach($all_projects as $blogs){ ?>
                                    <li><img src="<?php echo SITEURL ?><?php echo isset($blogs['photourl'])? $blogs['photourl']: '' ?>" alt="<?php echo isset($blogs['alt_name'])? $blogs['alt_name']: '' ?>"><a href="<?php echo SITEURL . 'blogs/' . $blogs['alias']; ?>"><?php echo isset($blogs['title'])? $blogs['title']: '' ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>                          
                        </div>
                    </div>
                </div>