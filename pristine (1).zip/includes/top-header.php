<?php
include("classes/startup.php");
$core  = new Core;

?>

<?php $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>

<meta name="author" content="<?php echo isset($url)?$url:'' ?>"/>
<meta name="robots" content="index, follow"/>
<meta name="rating" content="safe for kids"/>
<meta name="googlebot" content=" index, follow"/>
<meta name="allow-search" content="yes"/>
<meta name="revisit-after" content="daily"/>
<meta name="language" content="en-US"/>
<meta name="distribution" content="global"/>
<link rel="canonical" href="<?php echo isset($url)?$url:'' ?>"/>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo SITEURL?>assets/img/favicon.png">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/slick.min.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/slider.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/magnific-popup.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/nice-select.css">
<link rel="stylesheet" href="<?php echo SITEURL?>assets/css/main.css">
