<?php

include("classes/startup.php");
$core  = new Core;
$gallery = new MV_Gallery;
$about_data = new MV_AboutUs;
$service = new MV_Service;
$others = new MV_Others;
$pr_testimonials = new MV_Testimonials;
$service_home = new MV_Service_home;
$mv_welcome = new MV_Welcome;
$mv_blog = new MV_Blog;
$contactus = new MV_Contactus;
$contact = $contactus->index();


$all_projects = $mv_blog->index_limit();
$welcome_data = $mv_welcome->index();
$service_home_data = $service_home->index(2);
$service_data = $service->index(2);
$about = $about_data->index();
$gallery_data = $gallery->index(2);
$others_data = $others->index(2);
$testimonials = $pr_testimonials->index();

?>

<header class="header header-one">
    <div class="top-header-one top-bar">
        <div class="container">
            <div class="top-bar-inner">
                <div class="top-left">
                    <ul>
                        <li><i class="fa fa-phone-volume"></i> <a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><?php echo isset($contact['phone'])? $contact['phone']: '' ?></a></li>
                        <li><i class="fa fa-map-marker-alt"></i> <a href="https://maps.app.goo.gl/i1Lsm12HU5n7RBii9" target="_blank"><?php echo isset($contact['address'])? $contact['address']: '' ?></a></li>
                        <li class="mob-none"><i class="fa fa-envelope"></i> <a href="mailto:<?php echo isset($contact['email'])? $contact['email']: '' ?>"><?php echo isset($contact['email'])? $contact['email']: '' ?></a></li>
                    </ul>
                </div>
                <div class="top-right">
                    <ul class="top-social">
                        <li><a href="<?php echo isset($contact['facebook'])? $contact['facebook']: '' ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="<?php echo isset($contact['yelp'])? $contact['yelp']: '' ?>" target="_blank"><i class="fab fa-yelp"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!-- /.top-bar -->
    <div class="primary-header-one primary-header">
        <div class="container">
            <div class="primary-header-inner">
                <div class="header-logo">
                    <a href="<?php echo SITEURL; ?>"><img src="<?php echo SITEURL ?>assets/img/logo.webp" alt="Post Construction Cleaning in North & South Carolina" /></a>
                </div><!-- /.header-logo -->
                <div class="header-menu-wrap">
                    <ul class="dl-menu">
                        <li><a href="<?php echo SITEURL; ?>">Home</a></li>
                        <li><a href="<?php echo SITEURL; ?>about-us.php">About Us</a></li>
                        <li><a href="#">Services</a>
                            <ul>
                                <li><a href="#">Residential Cleaning</a>
                                    <ul>
                                        <?php foreach($service_data as $residential){ ?>
                                        <li><a href="<?php echo SITEURL . 'residential/' . $residential['alias']; ?>"><?php echo isset($residential['name']) ?  $residential['name'] : '' ?></a></li>
                                        <?php } ?>
                                    </ul>

                                </li>
                                <li>
                                    <a href="#">Commercial Cleaning</a>
                                    <ul>
                                    <?php foreach($others_data as $commercial){ ?>
                                        <li><a href="<?php echo SITEURL . 'disinfection/' . $commercial['alias']; ?>"><?php echo isset($commercial['name']) ?  $commercial['name'] : '' ?></a></li>
                                        <?php } ?>                                        
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="<?php echo SITEURL; ?>gallery.php">Gallery</a></li>
                        <li><a href="<?php echo SITEURL; ?>blogs.php">Blogs</a></li>
                        <li><a href="<?php echo SITEURL; ?>contact-us.php">Contact Us</a></li>
                    </ul>
                </div><!-- /.header-menu-wrap -->
                <div class="header-right">
                    <a class="header-btn" href="<?php echo SITEURL; ?>book-now.php">Book Now<span></span></a>
                    <a class="header-btn" href="<?php echo SITEURL; ?>#get">Get Free Estimate<span></span></a>
                    <!-- Burger menu -->
                    <div class="mobile-menu-icon">
                        <div class="burger-menu">
                            <div class="line-menu line-half first-line"></div>
                            <div class="line-menu"></div>
                            <div class="line-menu line-half last-line"></div>
                        </div>
                    </div>
                </div><!-- /.header-right -->
            </div><!-- /.primary-header-one-inner -->
        </div>
    </div><!-- /.primary-header-one -->
</header>