<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$others = new MV_Others;

if (isset($_REQUEST['did'])) {
    $did = (int)$_REQUEST['did'];
    if ($others->delete($did)) {
        $alert_data = array(
            "status" => "Record Deleted",
            "icon" => "success",
            "page_url" => "manage_commercial_cleaning.php"
        );
    } else {
        $alert_data = array(
            "status" => "Record Not Deleted",
            "icon" => "error",
            "page_url" => "manage_commercial_cleaning.php"
        );
    }
    $core->set_sweetalert($alert_data);
} else if (isset($_REQUEST['homepage'])) {
    $status = (isset($_REQUEST['status']) && $_REQUEST['status'] == 1) ? 0 : 1;
    $others->update_homepage_status($_REQUEST['homepage'], $status);
    $alert_data = array(
        "status" => "Service Updated",
        "icon" => "success",
        "page_url" => "manage_commercial_cleaning.php"
    );
    $core->set_sweetalert($alert_data);
}



$others_data = $others->index(2);

$page_name = 'commercial';

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                       Commercial Cleaning
                    <a href="manage_commercial_cleaning_add.php" title="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add New</a>
                </div>

                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Sr. No</th>
                                <th scope="col">Title</th>                              
                                <th scope="col">Image</th>
                                <!-- <th scope="col">Action</th> -->
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cnt = 1;
                            foreach ($others_data as $details) {
                            ?>
                                <tr>
                                    <td><?php echo $cnt ?></td>

                                    <td><?php echo isset($details['name']) ? $details['name'] : '' ?></td>


                                  
                                    <td>
                                            <img src="<?php echo isset($details['photourl'])?'../'.$details['photourl']:'images/noimage.png' ?>" width="60" style="border-radius:10%;"  alt="">
                                        </td>

                                   

                                    <td><a href="manage_commercial_cleaning_add.php?eid=<?php echo $details['id'] ?>"><span class="fa fa-pencil-square-o"></span></a></td>
                                    <td><a href="manage_commercial_cleaning.php?did=<?php echo $details['id'] ?>"><span class="fa fa-trash-o"></span></a></td>

                                </tr>
                            <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>


        <?php include("includes/footer.php"); ?>
    </div>

</body>

</html>