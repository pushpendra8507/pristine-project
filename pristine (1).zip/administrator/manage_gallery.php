<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$gallery = new MV_Gallery;

if (isset($_REQUEST['did'])) {
    $did = (int)$_REQUEST['did'];
    if ($gallery->delete($did)) {
        $alert_data = array(
            "status" => "Record Deleted",
            "icon" => "success",
            "page_url" => "manage_gallery.php"
        );
    } else {
        $alert_data = array(
            "status" => "Record Not Deleted",
            "icon" => "error",
            "page_url" => "manage_gallery.php"
        );
    }
    $core->set_sweetalert($alert_data);
} else if (isset($_REQUEST['homepage'])) {
    $status = (isset($_REQUEST['status']) && $_REQUEST['status'] == 1) ? 0 : 1;
    $gallery->update_homepage_status($_REQUEST['homepage'], $status);
    $alert_data = array(
        "status" => "gallery Updated",
        "icon" => "success",
        "page_url" => "manage_gallery.php"
    );
    $core->set_sweetalert($alert_data);
}

if (isset($_GET['delete_selected']) && !empty($_GET['items'])) {
    $itemsToDelete = explode(',', $_GET['items']);
    foreach ($itemsToDelete as $itemId) {
        $gallery->delete((int)$itemId);
    }
    
}



$gallery_data = $gallery->index(2);




$page_name = 'Gallery';

include("includes/top_header.php");
?>
<script>
    function deleteSelectedItems() {
    var selectedItems = document.querySelectorAll('input[name="selected_items[]"]:checked');
    if (selectedItems.length === 0) {
        alert("Please select at least one item to delete.");
        return;
    }
    
    var selectedValues = Array.from(selectedItems).map(item => item.value).join(',');
    window.location.href = "manage_gallery.php?delete_selected=1&items=" + selectedValues;
}
</script>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Gallery Page
                    <a href="manage_gallery_add.php" title="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add New</a>
                    
                    <a href="javascript:void(0);" onclick="deleteSelectedItems()" class="btn btn-danger" style="float: right; margin: -7px 18px;">Delete Selected</a>
                </div>

                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Sr. No</th>                  
                              
                                <th scope="col">Gallery-Image</th>
                                <th scope="col">Action</th>
                                <th scope="col">Click</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cnt = 1;
                            foreach ($gallery_data as $details) {
                            ?>
                                <tr>
                                    <td><?php echo $cnt ?></td>
                                    

                                   

                                    <td>
                                        <img src="<?php echo isset($details['photourl']) ? '../' . $details['photourl'] : 'images/noimage.png' ?>" width="60" style="border-radius:10%;" alt="">
                                    </td>


                                    <?php
                                    if ($details['homepage'] == 1) {
                                    ?>
                                        <td>
                                            <a href="manage_gallery.php?homepage=<?php echo $details['id'] . '&status=' . $details['homepage'] ?>"><span class="fa fa-check-circle" style="margin-right:1rem; color:green;"></span>Show On Homepage</a>
                                        </td>
                                    <?php
                                    } else {
                                    ?>
                                        <td>
                                            <a href="manage_gallery.php?homepage=<?php echo $details['id'] . '&status=' . $details['homepage'] ?>"><span class="fa fa-times-circle" style="margin-right:1rem; color:red;"></span>Show On Homepage</a>
                                        </td>
                                    <?php
                                    }
                                    ?>

                                 <td>
                                <input type="checkbox" name="selected_items[]" value="<?php echo $details['id']; ?>">

                                </td>
                                    <td><a href="manage_gallery_add.php?eid=<?php echo $details['id'] ?>"><span class="fa fa-pencil-square-o"></span></a></td>
                                    <td><a href="manage_gallery.php?did=<?php echo $details['id'] ?>"><span class="fa fa-trash-o"></span></a></td>

                                </tr>
                            <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>


        <?php include("includes/footer.php"); ?>
    </div>

</body>

</html>