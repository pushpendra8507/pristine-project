<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$gallery = new MV_Gallery;


if (isset($_POST['btn_submit'])) {

    $data['alt_name_gallery'] = (isset($_POST['alt_name_gallery']) && !empty($_POST['alt_name_gallery'])) ? $_POST['alt_name_gallery'] : '';
    $data['alt_name_home'] = (isset($_POST['alt_name_home']) && !empty($_POST['alt_name_home'])) ? $_POST['alt_name_home'] : '';

    if (empty($_POST['status'])) {
        $last_insert_id = $gallery->store($data);
    } else {
        $last_insert_id = $gallery->update($_POST['status'], $data);
    }

    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $last_insert_id > 0) {
        $path = '../uploads/gallery';
        $core->UploadImage($_FILES['fu_photo'], $path, 'pristine' . time() . $last_insert_id, 'tbl_gallery', 'photourl', 'id', $last_insert_id);
    }



    if ($last_insert_id > 0) {
        if (!empty($_POST['status'])) {
            $alert_data = array(
                "status" => "Record Updated",
                "icon" => "success",
                "page_url" => "manage_gallery.php"
            );
        } else {
            $alert_data = array(
                "status" => "Record Added",
                "icon" => "success",
                "page_url" => "manage_gallery.php"
            );
        }
    } else {
        $alert_data = array(
            "status" => "something went wrong",
            "icon" => "error",
            "page_url" => "manage_gallery.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

if (isset($_REQUEST["eid"])) {
    $details = $gallery->get_details($_REQUEST["eid"]);
}

$page_name = 'Gallery';

include("includes/top_header.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_gallery.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    <?php echo isset($_REQUEST['eid']) ? "Edit" : "Add"; ?>
                    Gallery Page
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" name="status" value="<?php echo (isset($_REQUEST['eid'])) ? $_REQUEST['eid'] : ""; ?>">

                        <div class="col-md-6" style="margin-bottom: 32px;">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image</label>
                                    <input type="file" name="fu_photo" id="image" />
                                </div>
                                <div class="col-md-6">
                                    <img width="60" style="border-radius:10%;" id="showImage" src="<?php echo (!empty($details['photourl'])) ? '../' . $details['photourl'] : '' ?>" />
                                </div>
                            </div>
                        </div>

                       

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="inputEmail3">Alt-Name </label>
                                <input type="text" name="alt_name_gallery" value="<?php echo (isset($details['alt_name_gallery'])) ? $details['alt_name_gallery'] : ''; ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>


                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="inputEmail3">Alt-Name-Home </label>
                                <input type="text" name="alt_name_home" value="<?php echo (isset($details['alt_name_home'])) ? $details['alt_name_home'] : ''; ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>


                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <?php include("includes/footer.php"); ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#image1').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage1').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>

</body>

</html>