<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$others = new MV_Others;
if (isset($_POST['btn_submit'])) {
    $data['seo_title'] = (isset($_POST['seo_title']) && !empty($_POST['seo_title'])) ? $_POST['seo_title'] : '';
    $data['seo_description'] = (isset($_POST['seo_description']) && !empty($_POST['seo_description'])) ? $_POST['seo_description'] : '';
    $data['seo_keyword'] = (isset($_POST['seo_keyword']) && !empty($_POST['seo_keyword'])) ? $_POST['seo_keyword'] : '';
    $data['seo_h1'] = (isset($_POST['seo_h1']) && !empty($_POST['seo_h1'])) ? $_POST['seo_h1'] : '';
    $data['seo_h2'] = (isset($_POST['seo_h2']) && !empty($_POST['seo_h2'])) ? $_POST['seo_h2'] : '';
    $data['name'] = (isset($_POST['name']) && !empty($_POST['name'])) ? $_POST['name'] : '';

    $data['alias'] = (isset($_POST['name']) && !empty($_POST['name'])) ? $core->alias_url($_POST['name']) : '';
 
    $data['description'] = (isset($_POST['description']) && !empty($_POST['description'])) ? $_POST['description'] : '';
   
    $data['alt_name'] = (isset($_POST['alt_name']) && !empty($_POST['alt_name'])) ? $_POST['alt_name'] : '';
        
    
    $service_provider = array();
    foreach($_POST['title'] as $key=>$value){
      $service_provider[$key]['title'] = $value;
      $service_provider[$key]['value_1'] = $_POST['value_1'][$key];
      $service_provider[$key]['value_2'] = $_POST['value_2'][$key];
      $service_provider[$key]['value_3'] = $_POST['value_3'][$key];
      $service_provider[$key]['value_4'] = $_POST['value_4'][$key];
  }

  $data['service_provider'] = json_encode($service_provider, true);


    if (empty($_POST['status'])) {
        $last_insert_id = $others->store($data);
    } else {
        $last_insert_id = $others->update($_POST['status'], $data);
    }
  
     
    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $last_insert_id > 0) {
        $path = '../uploads/service';
        $core->UploadImage($_FILES['fu_photo'], $path, 'pristine' . time() . $last_insert_id, 'tbl_others', 'photourl', 'id', $last_insert_id);
        
    }
    if ($last_insert_id > 0) {
        if (!empty($_POST['status'])) {
            $alert_data = array(
                "status" => "Record Updated",
                "icon" => "success",
                "page_url" => "manage_commercial_cleaning.php"
            );
        } else {
            $alert_data = array(
                "status" => "Record Added",
                "icon" => "success",
                "page_url" => "manage_commercial_cleaning.php"
            );
        }
    } else {
        $alert_data = array(
            "status" => "something went wrong",
            "icon" => "error",
            "page_url" => "manage_commercial_cleaning.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

if (isset($_REQUEST["eid"])) {
    $details = $others->get_details($_REQUEST["eid"]);
}
$service_providerArr = isset($details['service_provider']) ? json_decode($details['service_provider'], true) : "";

$page_name = 'commercial';

include("includes/top_header.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_commercial_cleaning.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    <?php echo isset($_REQUEST['eid']) ? "Edit" : "Add"; ?>
                   Commercial Cleaning
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" name="status" value="<?php echo (isset($_REQUEST['eid'])) ? $_REQUEST['eid'] : ""; ?>">
                        <div class="col-md-12">                   

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3">Seo-Titile </label>
                                    <input type="text" name="seo_title" value="<?php echo (isset($details['seo_title'])) ? $details['seo_title'] : ''; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>

                             
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3">Seo Description </label>
                                    <textarea class="form-control " name="seo_description"><?php echo isset($details['seo_description']) ? html_entity_decode($details['seo_description']) : '' ?></textarea>
                                </div>
                            </div>


                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3">Seo Keyword</label>
                                    <textarea class="form-control " name="seo_keyword"><?php echo isset($details['seo_keyword']) ? html_entity_decode($details['seo_keyword']) : '' ?></textarea>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3">Seo H1</label>
                                    <input type="text" name="seo_h1" value="<?php echo (isset($details['seo_h1'])) ? $details['seo_h1'] : ''; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3">Seo H2</label>
                                    <input type="text" name="seo_h2" value="<?php echo (isset($details['seo_h2'])) ? $details['seo_h2'] : ''; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>
                        
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Title </label>
                                    <input type="text" name="name" value="<?php echo (isset($details['name'])) ? $details['name'] : ''; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Description </label>
                                    <textarea class="form-control description" name="description"><?php echo isset($details['description']) ? html_entity_decode($details['description']) : '' ?></textarea>
                                </div>
                            </div>

                            <div class="form-group row" id="service_provider">
                            <label for="inputEmail3" class="col-sm-12 col-form-label"> Working Hours </label>
                            <?php if (!empty($service_providerArr)) {
                                $cnt = 1;
                                foreach ($service_providerArr as $value) {
                            ?>
                            <div class="col-md-10 item">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="title[]" value="<?php echo $value['title'] ?>"
                                            required="" class="form-control">
                                    </div>
                                </div>
                                
                               
                               
                               
                                <?php if ($cnt == 1) {  ?>
                                <button type="button" id="addbtn" class="btn btn-primary"><span
                                        class="fa fa-plus"></span></button>
                                <?php
                                        } else {
                                            ?>
                                <button class="btn btn-danger delbtn"><span class="fa fa-trash"></span>
                                </button>
                                <?php } ?>
                            </div>
                            <?php
                                    $cnt++;
                                }
                            } else {
                                    ?>
                            <div class="col-md-10 item">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="title[]" required="" class="form-control">
                                    </div>
                                </div>
                               

                                <button type="button" id="addbtn" class="btn btn-primary"><span
                                        class="fa fa-plus"></span></button>
                            </div>
                            <?php
                            }
                                ?>
                        </div>

                            <div class="col-md-6">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image</label>
                                    <input type="file" name="fu_photo" id="image" />
                                </div>
                                <div class="col-md-6">
                                    <img width="80" id="showImage" src="<?php echo (!empty($details['photourl'])) ? '../' . $details['photourl'] : '' ?>" />
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="inputEmail3">Alt-Name</label>
                                        <input type="text" name="alt_name" value="<?php echo (isset($details['alt_name'])) ? $details['alt_name'] : ''; ?>" class="form-control" id="inputEmail3" placeholder="alt-name">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>



<script type="text/javascript">
    var stmax_fields = Infinity; //maximum input boxes allowed
    var store_time = $("#service_provider"); //Fields wrapper
    var stadd_button = $("#addbtn"); //Add button ID

    var x = 1; //initlal text box count
    $(stadd_button).click(function(e) { //on add input button click
        e.preventDefault();
        if (x < stmax_fields) { //max input box allowed
            x++; //text box increment
            $(store_time).append(
                '<div class="col-md-10 item"><div class="col-md-3"><div class="form-group"><input type="text" name="title[]" required="" class="form-control"> </div></div><button class="btn btn-danger delbtn" ><span class="fa fa-trash"></span></button> </div>'
                ); //add input box
        }
    });

    $(store_time).on("click", ".delbtn", function(e) { //user click on remove text
        e.preventDefault();
        $(this).parent('div').remove();
        x--;
    })
    </script>

</body>

</html>