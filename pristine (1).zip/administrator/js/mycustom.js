$(document).ready(function(){
    $('#add_item').on('click',function(){
        var cnt=$("#itemdiv > div").length;
        cnt+=1;
        var content='<div id="itmdiv"><table class="table table-bordered"><thead><tr><td colspan="2"><button type="button" class="removeitem"  style="background: #F20;height: 20px;margin-bottom: 10px;float: right;"><span class="fa fa-minus"></span></button></td></tr></thead><tbody><tr><td></td><td><table id="item_attr_div" class="table table-bordered"><tr><td><input type="text" name="title[]"  required="" placeholder="Title Name" class="title form-control-half col-md-6"/><input type="text" name="details[]"  required="" placeholder="Additional Details" class="details form-control-half col-md-6"/><button type="button" id="add_item_attr" style="background: #008000;height: 30px;margin-bottom: 10px;float: right; color: #FFF;"><span class="fa fa-plus">Add</span></button></td></tr> </table></td></tr></tbody></table></div>';
        $('#itemdiv').append(content);
    })

    $('body').on('click','.removeitem',function(){
        //alert('hii');
        $(this).closest('div').remove();
    })
    $('body').on('click','.removeitem_attr',function(){
        //$(this).parent('tr').remove();
        $(this).closest("tr").remove();
    })
    $('body').on('click','#add_item_attr',function(){
        var parent_id=$(this).closest('div').attr('id');
        var arr = parent_id.split('-');
        var content=' <tr><td><input type="text" name="title[]"  required="" placeholder="Title" class="title form-control-half col-md-6"/><input type="text" name="details[]" required="" placeholder="Additional Details" class="details form-control-half col-md-6"/><button type="button" class="removeitem_attr"  style="background: #F20;height: 20px;margin-bottom: 10px; padding-bottom: 25px; float: right;"><span class="fa fa-minus"></span></button></td></tr>';
        $(this).closest("table").append(content);
    });
    
    
    $('#required_attribute').on('change',function(){
        if($(this).is(':checked')===true){
            $('.title').prop('required',true);
            $('.details').prop('required',true);
            $('.title').prop('disabled',false);
            $('.details').prop('disabled',false);
            $('#add_item_attr').prop('disabled',false);
        }
        else{
            $('#add_item_attr').prop('disabled',true);
            $('.title').prop('required',false);
            $('.details').prop('required',false);
            $('.title').prop('disabled',true);
            $('.details').prop('disabled',true);
        }
    })
    
    $('#form-required-attribute').on('submit',function(){
        var product_id = $('input[name="product_id"]').val();
        if(!product_id){
            alert('Invalid Product');
            return false;
        }
        return true;
    })
    
    $('body').on('click','.edit-attrib',function(){
        var attribute_index=$(this).attr('data-attribute_index');
        var product_id = $('input[name="product_id"]').val();
        if(product_id && attribute_index){
            $.ajax({
                type: 'POST',
                url: 'ajaxfiles/get_attribute_to_edit.php',
                data: { 'product_id': product_id,'attribute_index':attribute_index},
                success: function (response) {
                  $('#myModalRequiredEdit').modal('toggle');
                  $('#edit-required-model').html(response);
              }

          });
        }
    })
    
    $('body').on('click','.del-attrrib',function(){
        var attribute_index=$(this).attr('data-attribute_index');
        var product_id = $('input[name="product_id"]').val();
        if(product_id && attribute_index){
            $.ajax({
                type: 'POST',
                url: 'ajaxfiles/del_required_attribute.php',
                data: { 'product_id': product_id,'attribute_index':attribute_index},
                success: function (response) {
                 location.reload();
             }

         });
        }
    })

   
    
})
