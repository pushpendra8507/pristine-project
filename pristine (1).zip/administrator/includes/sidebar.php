<div class="col-md-2 sidebar">
    <div class="row">
        <div class="absolute-wrapper"> </div>
        <div class="side-menu">
            <nav class="navbar navbar-default" role="navigation">
                <div class="side-menu-container">
                    <ul class="nav navbar-nav">
                        <li class="dashboard
                      <?php if ($page_name === 'Dashboard') {
                          echo 'active';
                        } ?>">
                            <a href="dashboard.php"><span class="glyphicon glyphicon-dashboard">
                                </span> Dashboard</a>
                             </li>
                           <li class="panel panel-default" id="dropdown">
                            <a data-toggle="collapse" href="#dropdown-lvl1">
                                <span class="glyphicon glyphicon-user">
                                </span> Manage CMS <span class="caret"></span>
                            </a>
                            <div id="dropdown-lvl1" class="">
                                <div class="panel-body">
                                    <ul class="nav navbar-nav">
                                        <li class="<?php if ($page_name === 'Welcome') {
                                  echo 'active';
                                } ?>">
                                      <a href="manage_welcome.php">Manage Welcome</a>
                                        </li>
                                        <li class="<?php if ($page_name === 'AboutUs') {
                                  echo 'active';
                                } ?>">
                                            
                                            
                                            
                                            
                                            
                                            <a href="manage_about.php">Manage About</a>
                                        </li>
                                        <button class="dropdown-btn btnclr ">
                                            <i class="fa fa-list-alt"></i> Manage Service
                                            <i class="fa fa-caret-down"></i>
                                        </button>

                                        <div class="dropdown-container" style="display: <?php
                                                                   
                                                                    if ($page_name === 'Cleaning') {
                                                                      echo 'block;';
                                                                    } elseif ($page_name === 'commercial') {
                                                                      echo 'block;';
                                                                    } else {
                                                                      echo 'none;';
                                                                    } ?>">
                                            <ul>

                                                <li class="<?php if ($page_name === 'Cleaning') {
                                      echo 'active';
                                    } ?>">
                                                    <a href="manage_residential_cleaning.php"> Residential Cleaning</a>
                                                </li>

                                                <li class="<?php if ($page_name === 'commercial') {
                                      echo 'active';
                                    } ?>">
                                                    <a href="manage_commercial_cleaning.php"> Commercial Cleaning</a>
                                                </li>

                                            </ul>
                                        </div>


                                        <li class="<?php if ($page_name === 'Gallery') {
                                  echo 'active';
                                } ?>">
                                            <a href="manage_gallery.php">Manage Gallery</a>
                                        </li>

                                        <li class="<?php if ($page_name === 'ServiceHome') {
                                  echo 'active';
                                } ?>">
                                            <a href=" manage_service_home.php">Manage Home Service </a>
                                        </li>


                                        <li class="<?php if ($page_name === 'Blog') {
                                  echo 'active';
                                } ?>">
                                            <a href="manage_blogs.php">Manage Blogs </a>
                                        </li>

                                        <li class="<?php if ($page_name === 'Testimonials') {
                                  echo 'active';
                                } ?>">
                                            <a href="manage_testimonials.php">Manage Testimonials </a>
                                        </li>

                                        <li class="<?php if ($page_name === 'Contactus') {
                                  echo 'active';
                                } ?>">
                                            <a href="admin-contactus.php">Manage Contact Details</a>
                                        </li>
                                       
                                        
                                           <li  class="<?php if($page_name==='Appointments'){echo 'active';} ?>">
                                          <a href="admin-appointments.php"> Book Now Details</a>
                                        </li>
                                        
                                        
                                        
                                        <li  class="<?php if($page_name==='Contacts'){echo 'active';} ?>">
                                          <a href=" admin-contacts.php">Get Free Estimate</a>
                                        </li>


                                        <button class="dropdown-btn btnclr <?php
                                                        if ($page_name === 'Sales_Tax') {
                                                          echo 'active';
                                                        } elseif ($page_name === 'Password') {
                                                          echo 'active';
                                                        } elseif ($page_name === 'Email') {
                                                          echo 'active';
                                                        }
                                                        ?>">
                                            <i class="fa fa-list-alt"></i> Manage Profile
                                            <i class="fa fa-caret-down"></i>
                                        </button>
                                        <div class="dropdown-container" style="display: <?php
                                                                    if ($page_name === 'Password') {
                                                                      echo 'block';
                                                                    } elseif ($page_name === 'Email') {
                                                                      echo 'block';
                                                                    } else {
                                                                      echo 'none;';
                                                                    } ?>">
                                            <ul>

                                                <li class="<?php if ($page_name === 'Password') {
                                      echo 'active';
                                    } ?>">
                                                    <a href="change_password.php">Change Password</a>
                                                </li>
                                                <li class="<?php if ($page_name === 'Email') {
                                      echo 'active';
                                    } ?>">
                                                    <a href="change-email.php">Change Email</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>

<script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
        } else {
            dropdownContent.style.display = "block";
        }
    });
}
</script>