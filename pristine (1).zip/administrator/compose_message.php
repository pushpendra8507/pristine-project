<?php
session_start();
include_once '../classes/startup.php';

$fromEmail = "pushpendra639263@gmail.com";
$fromName = "Your Name"; 

if(isset($_GET['selected_emails'])) {
    $selectedEmails = urldecode($_GET['selected_emails']);
    $emailAddresses = explode(',', $selectedEmails);
}

// if(isset($emailAddresses)) {
//     foreach ($emailAddresses as $email) {
//         echo $email . "<br>"; 
//     }
// }

if(isset($_POST['btn_submit'])) {
    $emailBody = isset($_POST['email']) ? $_POST['email'] : '';

    if (empty($emailBody)) {
        echo '<script>alert("Please enter an email message.");</script>';
    } else {
       
        $fileData = $fileName = $fileType = "";
        $isFileUploaded = false;

        
        if(isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
            $allowedTypes = array('image/jpeg', 'image/png', 'image/gif');
            $fileTmpName = $_FILES['file']['tmp_name'];
            $fileType = mime_content_type($fileTmpName);

            if (in_array($fileType, $allowedTypes)) {
                $isFileUploaded = true;
                $fileName = $_FILES['file']['name'];
                
                $fileData = chunk_split(base64_encode(file_get_contents($fileTmpName)));
            } else {
                echo '<script>alert("Invalid file type. Allowed types: JPEG, PNG, GIF.");</script>';
                return; 
            }
        }

       
        $headers = "From: $fromName <$fromEmail>\r\n";
        $headers .= "Reply-To: $fromEmail\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary=\"PHP-alt\"\r\n";

        
        $body = "--PHP-alt\r\n";
        $body .= "Content-Type: text/html;charset=utf-8\r\n";
        $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
        $body .= "<html><body>" . $emailBody . "</body></html>\r\n";

        
        if($isFileUploaded) {
            $body .= "--PHP-alt\r\n";
            $body .= "Content-Type: $fileType; name=\"$fileName\"\r\n";
            $body .= "Content-Transfer-Encoding: base64\r\n";
            $body .= "Content-Disposition: attachment; filename=\"$fileName\"\r\n\r\n";
            $body .= $fileData . "\r\n";
        }

        $body .= "--PHP-alt--";

        
        $success = true;

       
        foreach ($emailAddresses as $recipient) {
            if(!mail($recipient, "Email Subject", $body, $headers)) { 
                $success = false;
                break; 
            }
        }
        
        if($success) {
            echo "<script>alert('Email sent successfully ');</script>";
        } else {
            echo "<script>alert('Failed to send email to one or more recipients.');</script>";
        }
    }
}
?>









<?php
$page_name = 'Email';
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default"
                        style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img
                            src="images/back.png"></a>
                    Change Email
                </div>
                <div class="panel-body">
                    <form id="emailForm" method="post" enctype="multipart/form-data">
                        <label for="email">Email Message:</label> <br>
                        <textarea id="email" name="email" rows="7" cols="100" style="padding: 
                        10px; border: 1px solid #ccc; border-radius: 5px; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5;"></textarea><br> <br>

                        <!-- File input for image upload -->
                        <input type="file" name="file">
                        <br> <br>
                        <button type="submit" name="btn_submit">Send Email</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include("includes/footer.php"); ?>
</body>
</html>
