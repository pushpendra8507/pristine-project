<?php
include_once '../classes/startup.php';
$core = new Core;
$about_data = new MV_AboutUs;



if (isset($_POST['btn_submit'])) {
    $payload = [];
    $payload['description'] = isset($_POST['description']) ? $_POST['description'] : '';
    $payload['title'] = isset($_POST['title']) ? $_POST['title'] : '';

    $update_id = $about_data->update($_POST);
    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $update_id > 0) {
        $path = '../uploads/aboutus';
        $core->UploadImage($_FILES['fu_photo'], $path, 'atempainting-' . time() . $update_id, 'tbl_aboutus', 'photourl', 'id', 1);
    }
    if (isset($_FILES['fu_photo_1']) && $_FILES['fu_photo_1']['name'] != "" && $update_id > 0) {
        $path = '../uploads/aboutus';
        $core->UploadImage($_FILES['fu_photo_1'], $path, 'atempainting-' . time() . $update_id, 'tbl_aboutus', 'photourl_1', 'id', 1);
    }


    if ($update_id > 0) {
        $alert_data = array(
            "status" => "updated",
            "icon" => "success",
            "page_url" => "manage_about.php"
        );
    } else {
        $alert_data = array(
            "status" => "Not updated",
            "icon" => "error",
            "page_url" => "manage_about.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

$details = $about_data->index();
$page_name = 'AboutUs';
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_about.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Edit AboutUs
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <div class="form-group">
                        <div class="form-group">
                            <div class="col-md-12">
                                <label for="inputEmail3">Title</label>
                                <input class="form-control" name="title" value="<?php echo (isset($details['title'])) ? html_entity_decode($details['title']) : '' ?>" required>
                            </div>
                        </div>                        


                        </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <label for="inputEmail3">Description </label>
                                <textarea class="form-control description" name="description" required><?php echo (isset($details['description'])) ? html_entity_decode($details['description']) : '' ?></textarea>

                            </div>
                        </div>
                         
                         

                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>
</body>
<script type="text/javascript">
    $(document).ready(function() {
        $('#image').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#showImage').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#image1').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#showImage1').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>

</html>