<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Residential Cleaning Service in Charlotte, NC - Pristine Cleaning Service</title>
    <meta name="description"
        content="Embrace a refreshing approach to residential cleaning service in Charlotte, NC with Pristine Cleaning. We transform your home into a haven of immaculate beauty. Visit Us now!">
    <meta name="keywords"
        content="Professional Office Cleaning, Commercial Cleaning Service, Best Disinfection Cleaning Company in North Carolina, Best Regular Cleaning, Janitorial Cleaning Service, Residential Cleaning Service in Charlotte, NC">
    <?php include("includes/top-header.php"); ?>
</head>
<body class="header-1">
    <?php include("includes/header.php"); ?>
    <section class="page-header-1 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none">About Us - Residential Cleaning Service in Charlotte, NC</h1>
                <h2 class="dis-none">Professional Office Cleaning in Charlotte, NC</h2>
                <h3 class="chng-clr">About Us</h3>
            </div>
        </div>
    </section>
    <?php $about = $about_data->index(); ?>
    <section class="padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 sm-padding">
                    <div class="about-content">
                        <div class="section-heading wow fadeInLeft" data-wow-delay="0">
                        <h3 class="chng-clr"><?php echo isset($about['title']) ? $about['title'] : '' ?></h3>
                         <p><?php echo isset($about['description']) ? $about['description'] : '' ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include("includes/footer.php"); ?>
</body>

</html>