<?php
include('classes/startup.php');
$core    = new Core;
$mv_blog = new MV_Blog;

if (!isset($_REQUEST['alias']) || empty($_REQUEST['alias'])) {
    header('location:index.php');
    exit;
}
?>

<?php $blogs_details = $mv_blog->get_details_by_alias($_REQUEST['alias']); ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php  echo isset($blogs_details['seo_title'])? $blogs_details['seo_title']: '' ?></title>
    <meta name="description"
        content="<?php  echo isset($blogs_details['seo_description'])? $blogs_details['seo_description']: '' ?>">
    <meta name="keywords"
        content="<?php  echo isset($blogs_details['seo_keyword'])? $blogs_details['seo_keyword']: '' ?>">
    <?php include ("includes/top-header.php");?>
</head>

<body class="header-1">
    <?php include ("includes/header.php");?>
    <section class="page-header-2 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none"><?php  echo isset($blogs_details['seo_h1'])? $blogs_details['seo_h1']: '' ?></h1>
                <h2 class="dis-none"><?php  echo isset($blogs_details['seo_h2'])? $blogs_details['seo_h2']: '' ?></h2>
                <h3 class="chng-clr">Blogs Details</h3>
            </div>
        </div>
    </section>
    <section class="blog-section padding">
        <div class="container">
            <div class="blog-wrap row">
                <div class="col-lg-8 padding-15">
                    <div class="blog-single-wrap">
                        <div class="blog-thumb">
                            <img src="<?php echo SITEURL ?><?php  echo isset($blogs_details['photourl'])? $blogs_details['photourl']: '' ?>"
                                alt="<?php  echo isset($blogs_details['alt_name'])? $blogs_details['alt_name']: '' ?>">
                        </div>
                        <div class="blog-single-content">
                            <h3><a
                                    href="<?php echo SITEURL ?>blogs.php"><?php  echo isset($blogs_details['title'])? $blogs_details['title']: '' ?></a>
                            </h3>
                            <ul class="single-post-meta">
                                <li><i class="fas fa-calendar"></i> <a
                                        href="#"><?php  echo isset($blogs_details['date'])? $blogs_details['date']: '' ?></a>
                                </li>
                                <li><i class="fas fa-comments"></i> <a href="#">0 Comments</a></li>
                            </ul>
                            <p><?php  echo isset($blogs_details['description'])? $blogs_details['description']: '' ?>
                            </p>
                            <div class="mt-2">
                                <!-- ShareThis BEGIN -->
                                <div class="sharethis-inline-share-buttons"></div><!-- ShareThis END -->
                            </div>
                            <p><?php  echo isset($blogs_details['tags'])? $blogs_details['tags']: '' ?></p>
                            <div class="post-navigation row">
                                <div class="col prev-post">
                                    <a href="#"><i class="ti-arrow-left"></i>Prev Post</a>
                                </div>
                                <div class="col next-post">
                                    <a href="#">Next Post <i class="ti-arrow-right"></i></a>
                                </div>
                            </div>
                            
                            <!-- /.post-navigation -->
                            <div class="comments-area">
                                <div class="comment-respond">
                                    <h3 class="comment-reply-title">Write a Comment</h3>
                                    <form method="post" class="comment-form">
                                        <div class="form-textarea">
                                            <textarea placeholder=" Comments..."></textarea>
                                        </div>
                                        <div class="form-inputs">
                                            <input placeholder="Full Name" type="text">
                                            <input placeholder="Email Address" type="email">
                                        </div>
                                        <div class="form-submit">
                                            <input value="Post Comment" type="submit">
                                        </div>
                                    </form>
                                </div>
                            </div><!-- /.comments-area -->
                        </div>
                    </div>
                    <!--/.blog-single-->
                </div>
                <!--/.col-lg-8-->
                <?php include('includes/sidebar.php'); ?>
            </div>
        </div>
    </section>
    <script type='text/javascript'
        src='https://platform-api.sharethis.com/js/sharethis.js#property=64de54d96dbfde0012ce1085&product=sop'
        async='async'></script>
    <?php include ("includes/footer.php");?>
</body>

</html>