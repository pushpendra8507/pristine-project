<?php
include'classes/startup.php';
include_once 'ContactFunctions.php';
 $appointments = new Contacts;

if(isset($_POST) && isset($_POST["btn_submit"]))
{
    if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
        echo '<script>window.location="./"</script>'; exit;
    }

    $name = $email = $phone = $service  = $msge = "";
    if($_SERVER["REQUEST_METHOD"] == "POST"){

      $secretKey  = '6LcJ8cQkAAAAACnWXE3H_8QxPgM8liTtxHb1IjZz';
      $token    = $_POST["g-token"];
      $ip     = $_SERVER['REMOTE_ADDR'];
      
      if(empty($_POST["name"])){
        echo '<script>window.location="./"</script>'; exit;
    } else{
        $name = filterName($_POST["name"]);
        if($name == FALSE){
            echo '<script>window.location="./"</script>'; exit;
        }
    }
    
    if(empty($_POST["email"])){
        echo '<script>window.location="./"</script>'; exit;    
    } else{
        $email = filterEmail($_POST["email"]);
        if($email == FALSE){
            echo '<script>window.location="./"</script>'; exit;
        }
    }

    $phone = (isset($_POST["phone"]) && !empty($_POST["phone"]))? $_POST["phone"]: '';
   $service = (isset($_POST["service"]) && !empty($_POST["service"]))? $_POST["service"]: '';

    // Validate user message
    if(empty($_POST["description"])){
        echo '<script>window.location="./"</script>'; exit;    
    } else{
        $msge = filterString($_POST["description"]);
        if($msge == FALSE){
            echo '<script>window.location="./"</script>'; exit;
        }
    }
 
    $url = "https://www.google.com/recaptcha/api/siteverify";
    $data = array('secret' => $secretKey, 'response' => $token, 'remoteip'=> $ip);

      // use key 'http' even if you send the request to https://...
    $options = array('http' => array(
        'method'  => 'POST',
        'content' => http_build_query($data)
    ));
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    $response = json_decode($result);
    if($response->success)
    {
         
        //  $to = 'ravi02.agp@gmail.com';
        //  $to = 'pushpendra629363@gmail.com';
            $to = 'info@pristinecleaningbusiness.com';
             $payload = [];
            $payload['name'] = isset($_POST['name'])?$_POST['name']:'';
            $payload['email'] = isset($_POST['email'])?$_POST['email']:'';
            $payload['phone'] = isset($_POST['phone'])?$_POST['phone']:'';
            $payload['service'] = isset($_POST['service'])?$_POST['service']:'';
            $payload['description'] = isset($_POST['description'])?$_POST['description']:'';
            
            
            if(!empty($payload['name']) && !empty($payload['email']) && !empty($payload['phone']) && !empty($payload['service'])  && !empty($payload['description']))
            {
                $appointments->create_appointment($payload);
            }
        
        $fromMail = 'no-reply@pristinecleaningclt.com';
        $fromName = "Pristine Cleaning Service";
        $subject = "Pristine Cleaning Service - Contact Form";
        $message = '<html><head><title>Pristine Cleaning Service</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
            <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

            <tr>
            <td height="25"  colspan="2"><center><strong>Pristine Cleaning Service</strong></center></td>
            </tr>
            </table>
            <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
                <tbody>
                    <tr>
                        <td width="100%" valign="top">
                            <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                                <tbody>     
                                    <tr>
                                        <td colspan="2"><center><strong>Contact Form</strong></center></td>
                                    </tr>
                                    <tr>
                                        <td width="30%">Name:</td>
                                        <td width="70%">' . $name . '</td>
                                    </tr>
                                    <tr>
                                        <td>Email:</td>
                                        <td>' . $email . '</td>
                                    </tr>
                                    <tr>
                                        <td>Phone:</td>
                                        <td>' . $phone . '</td>
                                    </tr>
                                    <tr>
                                        <td>Subject:</td>
                                        <td>' . $service . '</td>
                                    </tr>
                                    <tr>
                                        <td>Message:</td>
                                        <td>' . $msge . '</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div></body></html>';
            // To send HTML mail, the Content-type header must be set
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
            $headers .= 'From:'.$fromName." ".'<'.$fromMail.'>'."\r\n";
            $headers .= 'Bcc: contact@wxperts.co' . "\r\n";
            
            $message = str_replace("\'", "'", $message);
            //echo $message;exit;
            $send_mail = mail($to, $subject, $message, $headers);

            if($send_mail){
                //  echo '<script>window.location="https://www.isadorejohnsonsmiscellaneousservices.com/get-free-estimate.php?submit=success"</script>';die();
              echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
           }
           else 
           {
               echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
           }
       }
       else
       {
        echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
       }
    }
}

?>

<!doctype html>
   <html class="no-js" lang="en">
   <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Home & Office Cleaning in Charlotte, NC - Pristine Cleaning Service </title>
    <meta name="description" content="Connect with experts for premier home and office cleaning in Charlotte, NC with the Pristine Cleaning Service. Reach out today to experience a new level of cleanliness.">
    <meta name="keywords" content="Home & Office Cleaning in Charlotte, NC, Post Construction Cleaning in North & South Carolina, Janitorial Cleaning Service, Eco/Green Cleaning, Commercial Cleaning Service, Best Regular Cleaning">
    <?php include ("includes/top-header.php");?>
    <script src="https://www.google.com/recaptcha/api.js?render=6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh"></script>
</head>
<body class="header-1">
    <?php include ("includes/header.php");?>
    <section class="page-header-3 padding">
        <div class="container">
            <div class="page-content text-center">
                <h1 class="dis-none">Contact Us – Home & Office Cleaning in Charlotte, NC</h1>
                <h2 class="dis-none">Sanitization & Deep Cleaning Service in North & South Carolina</h2>
                <h3 class="chng-clr">Contact Us</h3>
            </div>
        </div>
    </section>
    <?php $contact = $contactus->index(); ?>
    <section class=" contact-sec">
            <div class="container">
                <div class="row">            
                 <div class="col-lg-4">
                    <div class="contact-details">
                        <div class="contact-info-1 bg-grey">
                            <div class="icon-box center">
                                <div class="icon-2"><span><i class="fa fa-phone"></i></span> </div>
                                
                                 <div class="icon-box">
                                    <div class="text mt-2 text-center"><a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><?php echo isset($contact['phone'])? $contact['phone']: '' ?></a></div>
                                </div>
                               
                            </div>
                        </div>                       
                    </div>                    
                </div>
                 <div class="col-lg-4">
                    <div class="contact-details">
                        <div class="contact-info-1 bg-grey">
                            <div class="icon-box center">
                                <div class="icon-1"><span class="fa fa-map-marker-alt"></span> </div>
                                
                                 <div class="icon-box">
                                    <div class="text mt-2 text-center"><a href="https://maps.app.goo.gl/i1Lsm12HU5n7RBii9" target="_blank"> <?php echo isset($contact['address'])? $contact['address']: '' ?></a>
                                    </div>
                                </div>
                               
                            </div>
                        </div>                       
                    </div>                    
                </div>
                <div class="col-lg-4">
                    <div class="contact-details">
                        <div class="contact-info-1 bg-grey">
                            <div class="icon-box center">
                                <div class="icon-1"><span class="fa fa-envelope"></span> </div>
                                
                                 <div class="icon-box">
                                    <div class="text mt-2 text-center"><a href="mailto:<?php echo isset($contact['email'])? $contact['email']: '' ?>"><?php echo isset($contact['email'])? $contact['email']: '' ?></a>
                                    </div>
                                </div>
                               
                            </div>
                        </div>                       
                    </div>                    
                </div>
        </div>
                <div class="row align-items-center">
                    <div class="col-lg-12 ">
                        <div class="contact-form">
                            <form action="#" method="post" class="form-horizontal">
                                <div class="form-group  colum-row row">
                                    <input type="hidden" id="g-token" name="g-token" />
                                    <div class="col-sm-6 form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Name" required>
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Email Address" required>
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <input type="text" name="service" class="form-control" placeholder="Services" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <textarea  name="description" cols="30" rows="5" maxlength="100" class="form-control message" placeholder="Message" required></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-12 text-center">
                                        <button id="submit" name="btn_submit" class="default-btn" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="map-sec">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d417020.35561758897!2d-80.8325254!3d35.2569641!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8856a7d2ef3cce7f%3A0x674ecdf689959e43!2sPristine%20Cleaning%20Service!5e0!3m2!1sen!2sus!4v1710434977441!5m2!1sen!2sus" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </section>

        <script>
            grecaptcha.ready(function() {
            grecaptcha.execute('6LcJ8cQkAAAAAJeER-PWOh_M3RaNlk9t1yJj1XBh', {action: 'homepage'}).then(function(token) {
            // console.log(token);
            document.getElementById("g-token").value = token;
            });
        });
        </script>
<?php include ("includes/footer.php");?>
</body>
</html>
